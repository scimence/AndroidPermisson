﻿package com.sc.demo;

import android.content.Intent;
import android.os.Bundle;

import com.sc.permission.FloatTool;
import com.sc.permission.PermissionActivity;
import com.sci.androidpermission.R;

/**  
 * 权限请求示例
 */
public class MainActivity extends PermissionActivity
{	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_main);
		
		FloatTool.RequestOverlayPermission(this);
	}
	
	/** Activity执行结果 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		FloatTool.onActivityResult(requestCode, resultCode, data, this);
	}
}
