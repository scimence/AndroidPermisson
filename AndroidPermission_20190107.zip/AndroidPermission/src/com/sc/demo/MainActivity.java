﻿package com.sc.demo;

import android.os.Bundle;

import com.sc.permission.PermissionActivity;
import com.sci.androidpermission.R;

/**  
 * 权限请求示例
 */
public class MainActivity extends PermissionActivity
{	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_main);
	}
}
